package assignments;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Assignments {
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        runAssignmentSolutions();
    }

    public static void runAssignmentSolutions() {
        int choice;
        do {
            clearScreen();
            System.out.println("====================================================");
            System.out.println("       CHOOSE PROBLEM TO SOLVE                      ");
            System.out.println("====================================================");
            System.out.println("problem 1: Compute Statistics of Numbers");
            System.out.println("problem 2: Find Second Largest Integer");
            System.out.println("problem 3: Compare Number of Factors");
            System.out.println("problem 4: Check Paired-N Array");
            System.out.println("problem 5: Exit");
            System.out.println("====================================================");
            
            choice = getIntInput("Enter your choice (1-5): ", 1, 5);
            
            switch(choice) {
                case 1: problem1(); break;
                case 2: problem2(); break;
                case 3: problem3(); break;
                case 4: problem4(); break;
                case 5: System.out.println("Exiting program..."); break;
            }
            
            if (choice != 5) {
                System.out.print("\nPress Enter to continue...");
                scanner.nextLine();
            }
            
        } while (choice != 5);
    }

    private static void problem1() {
        clearScreen();
        System.out.println("=== STATISTICS CALCULATOR ===");
        System.out.println("Enter numbers (0 to finish):\n");
        
        StatCalc calc = new StatCalc();
        while (true) {
            double num = getDoubleInput("Enter number: ");
            if (num == 0) break;
            calc.enter(num);
        }
        
        if (calc.getCount() > 0) {
            System.out.println("\nSTATISTICS RESULTS:");
            System.out.printf("Count: %d\n", calc.getCount());
            System.out.printf("Sum: %.2f\n", calc.getSum());
            System.out.printf("Mean: %.2f\n", calc.getMean());
            System.out.printf("Standard Deviation: %.2f\n", calc.getStandardDeviation());
            System.out.printf("Minimum: %.2f\n", calc.getMin());
            System.out.printf("Maximum: %.2f\n", calc.getMax());
        } else {
            System.out.println("No numbers entered.");
        }
    }

    private static void problem2() {
        clearScreen();
        System.out.println("=== FIND SECOND LARGEST NUMBER ===");
        
        int n = getIntInput("Enter number of elements: ", 0, Integer.MAX_VALUE);
        int[] arr = new int[n];
        
        System.out.println("\nEnter " + n + " integers:");
        for (int i = 0; i < n; i++) {
            arr[i] = getIntInput("Element " + (i+1) + ": ", Integer.MIN_VALUE, Integer.MAX_VALUE);
        }
        
        int result = findSecondLargest(arr);
        System.out.println("\nSecond largest number: " + (result == Integer.MIN_VALUE ? "-1 ->Doesn't exist" : result));
    }

    private static void problem3() {
        clearScreen();
        System.out.println("=== COMPARE NUMBER OF FACTORS ===");
        
        int n1 = getIntInput("Enter first number: ", -2147483647, Integer.MAX_VALUE);
        int n2 = getIntInput("Enter second number: ", -2147483647, Integer.MAX_VALUE);
        
        int result = sameNumberOfFactors(n1, n2);
        System.out.println("\nRESULT:");
        if (result == -1) {
            System.out.println("-1 ->Cannot compare negative numbers");
        } else if (result == 1) {
            System.out.println("1 ->Both have same number of factors");
        } else {
            System.out.println("0 ->Different number of factors");
        }
    }

    private static void problem4() {
        clearScreen();
        System.out.println("=== CHECK PAIRED-N ARRAY ===");
        
        int length = getIntInput("Enter array size (minimum 2): ", 0, Integer.MAX_VALUE);
        int[] arr = new int[length];
        
        System.out.println("\nEnter " + length + " integers:");
        for (int i = 0; i < length; i++) {
            arr[i] = getIntInput("Element " + (i+1) + ": ", Integer.MIN_VALUE, Integer.MAX_VALUE);
        }
        
        int n = getIntInput("Enter N value: ", 0, Integer.MAX_VALUE);
        boolean isPaired = isPairedN(arr, n) == 1;
        System.out.println("\nRESULT: " + (isPaired ? "1 ->IS PAIRED" : "0 ->NOT PAIRED-N"));
    }

    // Helper methods with robust input handling
    private static int getIntInput(String prompt, int min, int max) {
        while (true) {
            try {
                System.out.print(prompt);
                int value = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                
                if (value < min || value > max) {
                    System.out.printf("Please enter a value between %d and %d\n", min, max);
                    continue;
                }
                return value;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input! Please enter an integer.");
                scanner.nextLine(); // Clear invalid input
            }
        }
    }

    private static double getDoubleInput(String prompt) {
        while (true) {
            try {
                System.out.print(prompt);
                double value = scanner.nextDouble();
                scanner.nextLine(); // Consume newline
                return value;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input! Please enter a number.");
                scanner.nextLine(); // Clear invalid input
            }
        }
    }

    private static void clearScreen() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }

    // Original solution methods
    private static int findSecondLargest(int[] a) {
        if (a.length < 2) return Integer.MIN_VALUE;
        
        int largest = Integer.MIN_VALUE;
        int secondLargest = Integer.MIN_VALUE;
        
        for (int num : a) {
            if (num > largest) {
                secondLargest = largest;
                largest = num;
            } else if (num > secondLargest && num != largest) {
                secondLargest = num;
            }
        }
        return secondLargest;
    }

    private static int sameNumberOfFactors(int n1, int n2) {
        if (n1 < 0 || n2 < 0) return -1;
        if (n1 == n2) return 1;
        return countFactors(n1) == countFactors(n2) ? 1 : 0;
    }

    private static int countFactors(int n) {
        if (n == 0) return 0;
        if (n == 1) return 1;
        
        int count = 2; // 1 and n
        for (int i = 2; i <= n/2; i++) {
            if (n % i == 0) count++;
        }
        return count;
    }

    private static int isPairedN(int[] a, int n) {
        if (a.length < 2 || n < 0 || n > (a.length-1)*2) return 0;
        
        for (int i = 0; i < a.length; i++) {
            for (int j = i+1; j < a.length; j++) {
                if (a[i] + a[j] == n && i + j == n) return 1;
            }
        }
        return 0;
    }
}

class StatCalc {
    private int count;
    private double sum;
    private double sumOfSquares;
    private double min = Double.POSITIVE_INFINITY;
    private double max = Double.NEGATIVE_INFINITY;

    public void enter(double num) {
        count++;
        sum += num;
        sumOfSquares += num * num;
        min = Math.min(min, num);
        max = Math.max(max, num);
    }

    public int getCount() { return count; }
    public double getSum() { return sum; }
    public double getMean() { return sum / count; }
    public double getStandardDeviation() {
        return Math.sqrt(sumOfSquares / count - Math.pow(getMean(), 2));
    }
    public double getMin() { return min; }
    public double getMax() { return max; }
}