package bankingsystem;

import java.io.*;
import java.util.*;
import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.logging.Logger;

public class BankingSystem {
    private static final Logger logger = Logger.getLogger(BankingSystem.class.getName());
    private static ArrayList<Account> accounts = new ArrayList<>();
    private static Map<String, User> users = new HashMap<>();
    private static Scanner scanner = new Scanner(System.in);
    private static User currentUser = null;
    private static final String DATA_DIR = "data";
    private static final String DATA_FILE = DATA_DIR + "/banking_data.ser";
    private static final String USER_FILE = DATA_DIR + "/users_data.ser";
    private static final int MAX_LOGIN_ATTEMPTS = 3;

    public static void main(String[] args) {
        System.out.println("=== Welcome to Advanced Banking System ===");
        new File(DATA_DIR).mkdir();
        Runtime.getRuntime().addShutdownHook(new Thread(() -> saveData()));
        loadData();
        
        while (true) {
            try {
                if (currentUser == null) showLoginMenu();
                else showMainMenu();
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
                logger.warning("System error: " + e.getMessage());
            }
        }
    }
    
    private static void showLoginMenu() throws BankingException {
        System.out.println("\nLogin Menu:\n1. Login\n2. Create New Account\n3. Exit");
        System.out.print("Choose an option: ");
        
        switch (getIntInput()) {
            case 1: login(); break;
            case 2: createAccount(); break;
            case 3: 
                System.out.println("Thank you for using our banking system!");
                saveData();
                System.exit(0);
            default: System.out.println("Invalid choice. Please try again.");
        }
    }
    
    private static void showMainMenu() throws BankingException {
        System.out.println("\nMain Menu:\n1. Access Your Account\n2. Transfer Funds\n3. Logout\n4. Exit");
        System.out.print("Choose an option: ");
        
        switch (getIntInput()) {
            case 1: 
                Account account = findAccount(currentUser.getAccountNumber());
                if (account != null) accountMenu(account);
                else throw new BankingException("Account not found. Please contact support.");
                break;
            case 2:
                transferFunds();
                break;
            case 3: 
                System.out.println("Logging out...");
                currentUser = null;
                break;
            case 4: 
                System.out.println("Thank you for using our banking system!");
                saveData();
                System.exit(0);
            default: System.out.println("Invalid choice. Please try again.");
        }
    }
    
    private static void login() throws BankingException {
        if (users.isEmpty()) throw new BankingException("No users exist yet. Please create an account first.");
        
        int attempts = 0;
        while (attempts < MAX_LOGIN_ATTEMPTS) {
            try {
                System.out.print("\nUsername: ");
                String username = scanner.nextLine();
                System.out.print("Password: ");
                String password = scanner.nextLine();
                
                User user = users.get(username);
                if (user == null || !user.verifyPassword(hashPassword(password))) {
                    attempts++;
                    int remainingAttempts = MAX_LOGIN_ATTEMPTS - attempts;
                    if (remainingAttempts > 0) {
                        System.out.println("Invalid username or password. " + remainingAttempts + " attempts remaining.");
                    } else {
                        System.out.println("Maximum login attempts reached. Please try again later.");
                        return;
                    }
                    continue;
                }
                
                currentUser = user;
                System.out.println("Login successful! Welcome, " + username + "!");
                logger.info("User " + username + " logged in successfully");
                return;
            } catch (Exception e) {
                attempts++;
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private static void createAccount() throws BankingException {
        System.out.println("\n=== Create New Account ===");
        
        // Get full name with validation
        String name = getValidInput("Enter your full name: ", 
            input -> {
                if (input.trim().isEmpty()) throw new BankingException("Name cannot be empty");
                return input;
            });
        
        // Get username with validation
        String username = getValidInput("Create a username (min 4 chars): ", 
            input -> {
                if (input.length() < 4) throw new BankingException("Username must be at least 4 characters");
                if (users.containsKey(input)) throw new BankingException("Username already exists");
                return input;
            });
        
        // Get password with validation
        String password = getValidInput("Create a password (min 6 chars, at least 1 number): ", 
            input -> {
                if (input.length() < 6) throw new BankingException("Password must be at least 6 characters");
                if (!input.matches(".*\\d.*")) throw new BankingException("Password must contain at least 1 number");
                return input;
            });
        
        // Get date of birth with validation
        LocalDate dob = getValidInput("Date of Birth (YYYY-MM-DD): ", 
            input -> {
                LocalDate date = LocalDate.parse(input);
                if (Period.between(date, LocalDate.now()).getYears() < 18)
                    throw new BankingException("You must be at least 18 years old");
                return date;
            });
        
        // Get address
        String address = getValidInput("Address: ", 
            input -> {
                if (input.trim().isEmpty()) throw new BankingException("Address cannot be empty");
                return input;
            });
        
        // Get phone number with validation
        String phone = getValidInput("Phone Number (10-15 digits): ", 
            input -> {
                if (!input.matches("\\d{10,15}")) throw new BankingException("Phone must be 10-15 digits");
                return input;
            });
        
        // Get PIN with validation
        String pin = getValidInput("Create a 4-digit PIN: ", 
            input -> {
                if (!input.matches("\\d{4}")) throw new BankingException("PIN must be 4 digits");
                return input;
            });
        
        // Get account type with validation
        int typeChoice = getValidInput(
            "Select Account Type:\n1. Savings Account\n2. Checking Account\n3. Business Account\nChoose (1-3): ",
            input -> {
                int choice = Integer.parseInt(input);
                if (choice < 1 || choice > 3) throw new BankingException("Please select 1-3");
                return choice;
            });
        
        double minDeposit = (typeChoice == 3) ? 500.0 : 100.0;
        String accountType = (typeChoice == 1) ? "Savings" : (typeChoice == 2) ? "Checking" : "Business";
        
        // Get initial deposit with validation
        double initialDeposit = getValidInput(
            String.format("Initial Deposit (minimum $%.2f): $", minDeposit),
            input -> {
                double amount = Double.parseDouble(input);
                if (amount < minDeposit) throw new BankingException(String.format("Minimum deposit is $%.2f", minDeposit));
                return amount;
            });
        
        String accNumber = "AC" + String.format("%06d", accounts.size() + 1);
        Account newAccount;
        
        switch (typeChoice) {
            case 1: newAccount = new SavingsAccount(name, accNumber, pin, dob, address, phone, initialDeposit); break;
            case 2: newAccount = new CheckingAccount(name, accNumber, pin, dob, address, phone, initialDeposit); break;
            default: newAccount = new BusinessAccount(name, accNumber, pin, dob, address, phone, initialDeposit);
        }
        
        accounts.add(newAccount);
        users.put(username, new User(username, hashPassword(password), accNumber));
        saveData();
        
        System.out.printf("\nAccount created successfully!\nUsername: %s\nAccount Type: %s\nAccount Number: %s\nInitial Balance: $%.2f\n",
                         username, accountType, accNumber, initialDeposit);
        logger.info("New account created: " + accNumber + " for user " + username);
    }

    private static void transferFunds() throws BankingException {
        Account sourceAccount = findAccount(currentUser.getAccountNumber());
        if (sourceAccount == null) throw new BankingException("Source account not found");
        
        System.out.print("Enter destination account number: ");
        String destAccNumber = scanner.nextLine();
        Account destAccount = findAccount(destAccNumber);
        
        if (destAccount == null) throw new BankingException("Destination account not found");
        if (destAccount.getAccountNumber().equals(sourceAccount.getAccountNumber())) {
            throw new BankingException("Cannot transfer to same account");
        }
        
        double amount = getValidInput("Enter transfer amount: $", 
            input -> {
                double amt = Double.parseDouble(input);
                if (amt <= 0) throw new BankingException("Amount must be positive");
                return amt;
            });
        
        System.out.print("Enter your PIN to confirm: ");
        String pin = scanner.nextLine();
        
        if (!sourceAccount.verifyPin(pin)) {
            throw new BankingException("Invalid PIN. Transfer cancelled.");
        }
        
        sourceAccount.transfer(destAccount, amount);
        saveData();
        System.out.printf("Successfully transferred $%.2f to account %s\n", amount, destAccNumber);
        logger.info("Transfer of $" + amount + " from " + sourceAccount.getAccountNumber() + 
                  " to " + destAccNumber);
    }

    private static Account findAccount(String accNumber) {
        return accounts.stream().filter(a -> a.getAccountNumber().equals(accNumber)).findFirst().orElse(null);
    }

    private static void accountMenu(Account account) {
        while (true) {
            try {
                System.out.println("\nAccount Menu:");
                System.out.println("1. Deposit\n2. Withdraw\n3. View Balance");
                System.out.println("4. View Account Details\n5. View Transaction History");
                System.out.println("6. Change PIN\n7. Return to Main Menu");
                System.out.print("Choose an option: ");
                
                switch (getIntInput(1, 7)) {
                    case 1:
                        double depositAmount = getValidInput("Enter deposit amount: $", 
                            input -> {
                                double amt = Double.parseDouble(input);
                                if (amt <= 0) throw new BankingException("Amount must be positive");
                                return amt;
                            });
                        account.deposit(depositAmount);
                        saveData();
                        break;
                    case 2:
                        double withdrawAmount = getValidInput("Enter withdrawal amount: $", 
                            input -> {
                                double amt = Double.parseDouble(input);
                                if (amt <= 0) throw new BankingException("Amount must be positive");
                                return amt;
                            });
                        account.withdraw(withdrawAmount);
                        saveData();
                        break;
                    case 3: 
                        account.displayBalance(); 
                        break;
                    case 4: 
                        account.displayFullDetails(); 
                        break;
                    case 5: 
                        account.displayTransactionHistory(); 
                        break;
                    case 6:
                        changePin(account);
                        break;
                    case 7: 
                        return;
                }
            } catch (BankingException e) {
                System.out.println("Error: " + e.getMessage());
                logger.warning("Account operation error: " + e.getMessage());
            }
        }
    }
    
    private static void changePin(Account account) throws BankingException {
        System.out.print("Enter current PIN: ");
        String currentPin = scanner.nextLine();
        
        if (!account.verifyPin(currentPin)) {
            throw new BankingException("Incorrect current PIN");
        }
        
        String newPin = getValidInput("Enter new 4-digit PIN: ", 
            input -> {
                if (!input.matches("\\d{4}")) throw new BankingException("PIN must be 4 digits");
                return input;
            });
        
        String confirmPin = getValidInput("Confirm new PIN: ", 
            input -> {
                if (!input.equals(newPin)) throw new BankingException("PINs do not match");
                return input;
            });
        
        account.setPin(newPin);
        saveData();
        System.out.println("PIN changed successfully");
        logger.info("PIN changed for account " + account.getAccountNumber());
    }
    
    private static String hashPassword(String password) throws BankingException {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = md.digest(password.getBytes());
            return Base64.getEncoder().encodeToString(hashedBytes);
        } catch (Exception e) {
            throw new BankingException("Password hashing failed");
        }
    }
    
    private static void saveData() {
        try (ObjectOutputStream accountsOut = new ObjectOutputStream(new FileOutputStream(DATA_FILE));
             ObjectOutputStream usersOut = new ObjectOutputStream(new FileOutputStream(USER_FILE))) {
            accountsOut.writeObject(accounts);
            usersOut.writeObject(users);
            logger.info("Data saved successfully");
        } catch (IOException e) {
            System.out.println("Error saving data: " + e.getMessage());
            logger.severe("Data save error: " + e.getMessage());
        }
    }
    
    @SuppressWarnings("unchecked")
    private static void loadData() {
        try (ObjectInputStream accountsIn = new ObjectInputStream(new FileInputStream(DATA_FILE))) {
            accounts = (ArrayList<Account>) accountsIn.readObject();
            logger.info("Loaded " + accounts.size() + " accounts from file");
        } catch (FileNotFoundException e) {
            logger.info("No existing account data found. Starting fresh.");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error loading account data: " + e.getMessage());
            logger.severe("Account data load error: " + e.getMessage());
        }
        
        try (ObjectInputStream usersIn = new ObjectInputStream(new FileInputStream(USER_FILE))) {
            users = (Map<String, User>) usersIn.readObject();
            logger.info("Loaded " + users.size() + " users from file");
        } catch (FileNotFoundException e) {
            logger.info("No existing user data found. Starting fresh.");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error loading user data: " + e.getMessage());
            logger.severe("User data load error: " + e.getMessage());
        }
    }

    private static <T> T getValidInput(String prompt, InputValidator<T> validator) throws BankingException {
        while (true) {
            try {
                System.out.print(prompt);
                String input = scanner.nextLine();
                return validator.validate(input);
            } catch (BankingException e) {
                System.out.println("Error: " + e.getMessage() + ". Please try again.");
            } catch (Exception e) {
                System.out.println("Error: Invalid input format. Please try again.");
            }
        }
    }

    private static int getIntInput() throws BankingException {
        try {
            return Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            throw new BankingException("Invalid input. Enter a number");
        }
    }

    private static int getIntInput(int min, int max) throws BankingException {
        int input = getIntInput();
        if (input < min || input > max)
            throw new BankingException(String.format("Input must be between %d and %d", min, max));
        return input;
    }

    @FunctionalInterface
    private interface InputValidator<T> {
        T validate(String input) throws BankingException;
    }
}

class BankingException extends Exception {
    public BankingException(String message) { super(message); }
}

abstract class Account implements Serializable {
    private static final long serialVersionUID = 1L;
    private String accountHolderName, accountNumber, pin, address, phoneNumber;
    private LocalDate dateOfBirth;
    private double balance;
    private ArrayList<Transaction> transactionHistory;

    public Account(String name, String accNumber, String pin, LocalDate dob, 
                  String address, String phone, double initialDeposit) {
        this.accountHolderName = name;
        this.accountNumber = accNumber;
        this.pin = pin;
        this.dateOfBirth = dob;
        this.address = address;
        this.phoneNumber = phone;
        this.balance = initialDeposit;
        this.transactionHistory = new ArrayList<>();
        if (initialDeposit > 0) addTransaction("Initial Deposit", initialDeposit);
    }

    public String getAccountHolderName() { return accountHolderName; }
    public String getAccountNumber() { return accountNumber; }
    public double getBalance() { return balance; }
    public LocalDate getDateOfBirth() { return dateOfBirth; }
    public String getAddress() { return address; }
    public String getPhoneNumber() { return phoneNumber; }
    public boolean verifyPin(String inputPin) { return pin.equals(inputPin); }
    public int getAge() { return Period.between(dateOfBirth, LocalDate.now()).getYears(); }
    protected void setBalance(double balance) { this.balance = balance; }
    public void setPin(String newPin) { this.pin = newPin; }

    public void deposit(double amount) throws BankingException {
        if (amount <= 0) throw new BankingException("Invalid deposit amount");
        balance += amount;
        addTransaction("Deposit", amount);
        System.out.println("Deposited: $" + amount);
    }

    public abstract void withdraw(double amount) throws BankingException;

    public void transfer(Account recipient, double amount) throws BankingException {
        if (amount <= 0) throw new BankingException("Invalid transfer amount");
        withdraw(amount);
        recipient.deposit(amount);
        addTransaction("Transfer to " + recipient.getAccountNumber(), amount);
        recipient.addTransaction("Transfer from " + getAccountNumber(), amount);
    }

    protected void addTransaction(String type, double amount) {
        transactionHistory.add(new Transaction(type, amount, LocalDate.now()));
    }

    public void displayTransactionHistory() {
        System.out.println("\n=== Transaction History ===");
        if (transactionHistory.isEmpty()) {
            System.out.println("No transactions found.");
            return;
        }
        
        System.out.println("Date\t\tType\t\tAmount\t\tBalance");
        System.out.println("--------------------------------------------------");
        
        double runningBalance = 0;
        for (Transaction t : transactionHistory) {
            if (t.getType().startsWith("Deposit") || t.getType().startsWith("Initial")) {
                runningBalance += t.getAmount();
            } else if (t.getType().startsWith("Withdrawal") || t.getType().contains("fee") || t.getType().startsWith("Transfer to")) {
                runningBalance -= t.getAmount();
            } else if (t.getType().startsWith("Transfer from")) {
                runningBalance += t.getAmount();
            }
            System.out.printf("%s\t%s\t$%.2f\t\t$%.2f\n", 
                t.getDate(), t.getType(), t.getAmount(), runningBalance);
        }
    }

    public void displayBalance() {
        System.out.printf("\nAccount Details:\nHolder: %s\nNumber: %s\nBalance: $%.2f\n", 
                         accountHolderName, accountNumber, balance);
    }

    public void displayFullDetails() {
        displayBalance();
        System.out.printf("DOB: %s\nAge: %d\nAddress: %s\nPhone: %s\n", 
                         dateOfBirth, getAge(), address, phoneNumber);
    }
}

class SavingsAccount extends Account {
    private static final long serialVersionUID = 1L;
    private static final double MIN_BALANCE = 100.0;
    private static final double INTEREST_RATE = 0.02; // 2% annual interest

    public SavingsAccount(String name, String accNumber, String pin, 
                        LocalDate dob, String address, String phone, double initialDeposit) {
        super(name, accNumber, pin, dob, address, phone, initialDeposit);
    }

    @Override
    public void withdraw(double amount) throws BankingException {
        if (amount <= 0) throw new BankingException("Invalid withdrawal amount");
        if (getBalance() - amount < MIN_BALANCE) 
            throw new BankingException(String.format("Withdrawal failed. Minimum balance requirement ($%.2f) not met", MIN_BALANCE));
        
        setBalance(getBalance() - amount);
        addTransaction("Withdrawal", amount);
        System.out.println("Withdrawn: $" + amount);
    }

    public void applyInterest() {
        double interest = getBalance() * INTEREST_RATE / 12; // Monthly interest
        setBalance(getBalance() + interest);
        addTransaction("Interest Payment", interest);
    }
}

class CheckingAccount extends Account {
    private static final long serialVersionUID = 1L;
    private static final double OVERDRAFT_LIMIT = 500.0;
    private static final double OVERDRAFT_FEE = 25.0;

    public CheckingAccount(String name, String accNumber, String pin, 
                         LocalDate dob, String address, String phone, double initialDeposit) {
        super(name, accNumber, pin, dob, address, phone, initialDeposit);
    }

    @Override
    public void withdraw(double amount) throws BankingException {
        if (amount <= 0) throw new BankingException("Invalid withdrawal amount");
        if (getBalance() - amount < -OVERDRAFT_LIMIT) 
            throw new BankingException(String.format("Withdrawal failed. Overdraft limit ($%.2f) exceeded", OVERDRAFT_LIMIT));
        
        setBalance(getBalance() - amount);
        addTransaction("Withdrawal", amount);
        System.out.println("Withdrawn: $" + amount);
        
        if (getBalance() < 0) {
            System.out.println("Warning: Account is overdrawn! Fee will be applied at end of month.");
        }
    }

    public void applyOverdraftFee() {
        if (getBalance() < 0) {
            setBalance(getBalance() - OVERDRAFT_FEE);
            addTransaction("Overdraft Fee", OVERDRAFT_FEE);
        }
    }
}

class BusinessAccount extends Account {
    private static final long serialVersionUID = 1L;
    private static final double TRANSACTION_FEE = 2.5;
    private static final double MIN_BALANCE = 500.0;

    public BusinessAccount(String name, String accNumber, String pin, 
                          LocalDate dob, String address, String phone, double initialDeposit) {
        super(name, accNumber, pin, dob, address, phone, initialDeposit);
    }

    @Override
    public void withdraw(double amount) throws BankingException {
        if (amount <= 0) throw new BankingException("Invalid withdrawal amount");
        double totalCost = amount + TRANSACTION_FEE;
        if (getBalance() - totalCost < -MIN_BALANCE) 
            throw new BankingException(String.format("Withdrawal failed. Minimum balance requirement ($%.2f) not met", -MIN_BALANCE));
        
        setBalance(getBalance() - totalCost);
        addTransaction("Withdrawal", amount);
        addTransaction("Transaction Fee", TRANSACTION_FEE);
        System.out.printf("Withdrawn: $%.2f\nTransaction fee: $%.2f\n", amount, TRANSACTION_FEE);
    }
}

class Transaction implements Serializable {
    private static final long serialVersionUID = 1L;
    private String type;
    private double amount;
    private LocalDate date;
    
    public Transaction(String type, double amount, LocalDate date) {
        this.type = type;
        this.amount = amount;
        this.date = date;
    }
    
    public String getType() { return type; }
    public double getAmount() { return amount; }
    public LocalDate getDate() { return date; }
}

class User implements Serializable {
    private static final long serialVersionUID = 1L;
    private String username, password, accountNumber;
    
    public User(String username, String password, String accountNumber) {
        this.username = username;
        this.password = password;
        this.accountNumber = accountNumber;
    }
    
    public String getUsername() { return username; }
    public boolean verifyPassword(String inputPassword) { return password.equals(inputPassword); }
    public String getAccountNumber() { return accountNumber; }
}