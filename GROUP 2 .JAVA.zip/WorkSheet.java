package worksheet;

import java.util.Scanner;
import java.util.Random;

public class WorkSheet {
    // Employee class moved to beginning
    static class Employee {
        String lastName;
        String firstName;
        double hourlyWage;
        int yearsWithCompany;
    }

    // Static method for finding largest value in array (Question 4)
    public static int findLargestValue(int[] array) {
        if (array == null || array.length == 0) {
            throw new IllegalArgumentException("Input array cannot be null or empty");
        }

        int max = array[0];
        for (int num : array) {
            if (num > max) {
                max = num;
            }
        }
        return max;
    }

    // Method for Question 15: Sum odds minus sum evens
    public static int sumOddsMinusEvens(int[] arr) {
        int sumOdd = 0;
        int sumEven = 0;

        for (int num : arr) {
            if (num % 2 != 0) {
                sumOdd += num;
            } else {
                sumEven += num;
            }
        }
        return sumOdd - sumEven;
    }

    // Method for Question 16: Check if array is stepped
    public static int isStepped(int[] a) {
        if (a == null || a.length < 3) return 0;

        // Check ascending order
        for (int i = 0; i < a.length - 1; i++) {
            if (a[i] > a[i + 1]) return 0;
        }

        // Check occurrences
        int current = a[0];
        int count = 1;
        for (int i = 1; i < a.length; i++) {
            if (a[i] == current) {
                count++;
            } else {
                if (count < 3) return 0;
                current = a[i];
                count = 1;
            }
        }
        return count >= 3 ? 1 : 0;
    }

    // Player class for Question 8
    static class Player {
        private String name;
        private int score;

        public Player() {
            this("", 0);
        }

        public Player(String name, int score) {
            this.name = name;
            this.score = score;
        }

        // Getters and setters
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public int getScore() { return score; }
        public void setScore(int score) { this.score = score; }
    }

    // Counter class for Questions 9-10
    static class Counter {
        private int value;

        public Counter() {
            this.value = 0;
        }

        public void increment() {
            value++;
        }

        public int getValue() {
            return value;
        }
    }

    // PairOfDice class for Question 12
    static class PairOfDice {
        private int die1;
        private int die2;
        private Random random;

        public PairOfDice() {
            random = new Random();
            roll();
        }

        public void roll() {
            die1 = random.nextInt(6) + 1;
            die2 = random.nextInt(6) + 1;
        }

        public int getDie1() { return die1; }
        public int getDie2() { return die2; }
        public int getTotal() { return die1 + die2; }
    }

    // Method for Question 13: Closest Fibonacci
    public static int closestFibonacci(int n) {
        if (n < 1) return 0;
        if (n == 1) return 1;

        int prev = 1;
        int curr = 1;
        while (curr <= n) {
            int next = prev + curr;
            prev = curr;
            curr = next;
        }
        return prev;
    }

    // Methods for Question 14: Prime Happy
    public static int isPrimeHappy(int n) {
        if (n <= 2) return 0;

        int sum = 0;
        boolean hasPrimes = false;
        for (int i = 2; i < n; i++) {
            if (isPrime(i)) {
                sum += i;
                hasPrimes = true;
            }
        }
        return hasPrimes && sum % n == 0 ? 1 : 0;
    }

    private static boolean isPrime(int num) {
        if (num <= 1) return false;
        if (num == 2) return true;
        if (num % 2 == 0) return false;
        for (int i = 3; i * i <= num; i += 2) {
            if (num % i == 0) return false;
        }
        return true;
    }

    // Helper methods for table formatting
    private static void printTableHeader() {
        System.out.println("+------------+------------+--------------+-------------------+");
        System.out.printf("| %-10s | %-10s | %-12s | %-17s |\n", 
                         "First Name", "Last Name", "Hourly Wage", "Years in Company");
        System.out.println("+------------+------------+--------------+-------------------+");
    }

    private static void printEmployeeRow(Employee emp) {
        System.out.printf("| %-10s | %-10s | %10.2f ETB | %17d |\n", 
                         emp.firstName, emp.lastName, emp.hourlyWage, emp.yearsWithCompany);
    }

    private static void printTableFooter() {
        System.out.println("+------------+------------+--------------+-------------------+");
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("==================================================================================");
            System.out.println("       OOP WORKSHEET QUESTIONS WITH THEIR SOLUTIONS              ");
            System.out.println("==================================================================================");
            System.out.println("************QUESTION LIST*****************");
            System.out.println("#QUESTION 1->Difference between while and do...while loops");
            System.out.println("#QUESTION 2->Print multiples of 3 using a for loop");
            System.out.println("#QUESTION 3->Output of a while loop doubling a number until 32");
            System.out.println("#QUESTION 4->Static method to find the largest value in an integer array");
            System.out.println("#QUESTION 5->Calculate average of non-zero values in a double array");
            System.out.println("#QUESTION 6->Purpose and definition of a constructor in a class");
            System.out.println("#QUESTION 7->Explanation of instance variables and instance methods");
            System.out.println("#QUESTION 8->Encapsulate class variables with private access and add getters/setters");
            System.out.println("#QUESTION 9->Create a Counter class with increment and getValue methods");
            System.out.println("#QUESTION 10->Simulate coin tosses using Counter objects for heads/tails");
            System.out.println("#QUESTION 11->Filter and display employee data based on years with company");
            System.out.println("#QUESTION 12->PairOfDice class with private dice variables and getter methods");
            System.out.println("#QUESTION 13->Find the closest Fibonacci number less than or equal to n");
            System.out.println("#QUESTION 14->Check if a number is prime-happy (sum of primes divisible by n)");
            System.out.println("#QUESTION 15->Function returning the difference between sums of odd and even numbers");
            System.out.println("#QUESTION 16->Determine if an array is stepped (ascending with ≥3 repeats per value)");
            System.out.println("==================================================================================");
            System.out.println("*******************choose the question to solve**************************");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("QUESTION 1: What is the main difference between a while loop and a do...while loop? "); 
                    System.out.println("*****ANSWER******");
                    System.out.println("    #while loop                                         #do while loop");
                    System.out.println("->checks the condition Before loop body executes      ->checks the condition Before loop body executes");
                    System.out.println("->excutes only if the condition is true               ->excutes one times even if the condition is false");
                    System.out.println("->we use this loop When loop may not run at all       ->we use this loop When loop must run at least once");
                    System.out.println("->syntax: while (condition) { ... }                   ->sysntax: do { ... } while (condition);");              
                    break;

                case 2:
                    System.out.println("QUESTION 2: Write for loop that will print out all the multiples of 3 from 3 to 36, that is: 3 6 9 12 \n" +
"15 18 21 24 27 30 33 36.");
                    System.out.println("*****ANSWER******");
                    System.out.println("Multiples of 3:");
                    for (int i = 3; i <= 36; i += 3) {
                        System.out.print(i + " ");
                    }
                    break;
                case 3:
                    System.out.println("QUESTION 3: Show the exact output that would be produced by the following main() routine:\n" +
                      "public static void main(String[] args) {\n" +
                      " int N;\n" +
                      " N = 1;\n" +
                      " while (N <= 32) {\n" +
                      " N = 2 * N;\n" +
                      " System.out.println (N); \n" +
                      " }\n" +
                      "}");
                    System.out.println("******ANSWER******");
                    System.out.println("Exact output of the given routine:");
                    int N = 1;
                    while (N <= 32) {
                        N = 2 * N;
                        System.out.println(N);
                    }
                    break;

                case 4:
                    System.out.println("QUESTION 4: . Write a complete static method that finds the largest value in an array of ints. The \n" +
                     "method should have one parameter, which is an array of type int[]. The largest \n" +
                      "number in the array should be returned as the value of the method.");
                    System.out.println("*****ANSWER******");
                    int[] nums = {5, 8, 2, 10, 3, 1};
                    System.out.println("Largest value: " + findLargestValue(nums));
                    break;
                case 5:
                    System.out.println("QUESTION 5: Suppose that A has been declared and initialized with the statement\n" +
                     "double[] A = new double[20];\n" +
                     "and suppose that A has already been filled with 20 values. Write a program segment \n" +
                     "that will find the average of all the non-zero numbers in the array. (The average is the \n" +
                     "sum of the numbers, divided by the number of numbers. Note that you will have to \n" +
                     "count the number of non-zero entries in the array.) Declare any variables that you use");
                    System.out.println("*****ANSWER******");
                    double[] A = new double[20];

                    // Read 20 values from keyboard
                    System.out.println("Enter 20 double values:");
                    for (int i = 0; i < A.length; i++) {
                        System.out.print("Value " + (i + 1) + ": ");
                        A[i] = scanner.nextDouble();
                    }

                    double sum = 0.0;
                    int count = 0;
                    // Calculate sum and count of non-zero numbers
                    for (int i = 0; i < A.length; i++) {
                        if (A[i] != 0.0) {
                            sum += A[i];
                            count++;
                        }
                    }

                    // Display results
                    if (count > 0) {
                        double average = sum / count;
                        System.out.println("\nSum of non-zero numbers: " + sum);
                        System.out.println("Average of non-zero numbers: " + average);
                    } else {
                        System.out.println("\nNo non-zero numbers were entered.");
                    }
                    break;
                case 6:
                    System.out.println("QUESTION 6: What is a constructor? What is the purpose of a constructor in a class?");
                    System.out.println("******ANSWER******");
                    System.out.println("What is a Constructor?");
                    System.out.println("A constructor in Java is a special method-like block that is called automatically when an object is created from a class.");
                    System.out.println("=========================================");
                    System.out.println("Key Characteristics of Constructors:\n" +
                            "1.Same name as the class\n" +
                            "->A constructor must have the exact same name as the class in which it is defined.\n" +
                            "2.No return type\n" +
                            "->Unlike methods, constructors do not have a return type not even void.\n" +
                            "3.Called automatically\n" +
                            "->When you use new ClassName(), Java automatically calls the constructor.");
                    System.out.println("=========================================");
                    System.out.println("Purpose of a Constructor:");
                    System.out.println("   - Initialize object state (set default values for variables).");
                    System.out.println("   - Allocate memory for the object.");
                    System.out.println("   - Support multiple initialization ways (constructor overloading).");
                    System.out.println("\nExample:");
                    System.out.println("class Player {");
                    System.out.println("    String name;");
                    System.out.println("    int score;");
                    System.out.println("    // Constructor");
                    System.out.println("    public Player(String name, int score) {");
                    System.out.println("        this.name = name;");
                    System.out.println("        this.score = score;");
                    System.out.println("    }");
                    System.out.println("}");
                    break;
                case 7:
                    System.out.println("QUESTION 7: What is meant by the terms instance variable and instance method?");
                    System.out.println("*****ANSWER******");
                    System.out.println("# INSTANCE VARIABLE");
                    System.out.println("An instance variable is a variable that is declared inside a  class,\n" +
                           "but outside any methods, and is associated with individual objects (instances) of the class.\n" +
                            "Each object created from the class has its own copy of the instance variable. \n"+
                            "Instance variables store data or state specific to each object. Instance variables are accessible by all instance methods of the class..");
                    System.out.println("Purpose: Stores the state (data) of an object.");
                    System.out.println("Key Points:");
                    System.out.println("  - Each object gets its own copy of instance variables.");
                    System.out.println("  - Exists as long as the object exists.");
                    System.out.println("  - Also called \"object-level variables\".");
                    System.out.println("\nExample:    \tclass Car {\n" +
                            "String color;  // Instance variable\n" +
                            "Car(String c) {\n" +
                            "     color = c;  // Initializing the instance variable\n" +
                            "    }\n" +
                            "}");
                    System.out.println("# INSTANCE METHOD");
                    System.out.println("Definition: A method defined inside a class that operates on instance variables.");
                    System.out.println("Purpose: Defines the behavior (actions) of an object.");
                    System.out.println("Key Points:");
                    System.out.println("   - Must be called on an object (object.method()).");
                    System.out.println("   - Can access and modify instance variables.");
                    System.out.println("   - Also called \"object-level methods\".");
                    System.out.println("\nExample:class Car {\n" +
                            "tring color;  // Instance variable\n" +
                            "Car(String c) {\n" +
                            " color = c;  // Initializing the instance variable\n" +
                            "}\n");
                    break;
                case 8:
                    System.out.println("PROBLEM 8: Modify the following class so that the two instance variables are private and there is a \n" +
                    "getter method and a setter method for each instance variable:\n" +
                    " public class Player {\n" +
                    " String name;\n" +
                    " int score;\n" +
                    " }");
                    System.out.println("*****ANSWER******");
                    Player player = new Player("Test", 100);
                    System.out.println("Player created: " + player.getName());
                    break;
                case 9:
                    System.out.println("QUESTION 9: For this problem, you should write a very simple but complete class. The class \n" +
                    "represents a counter that counts 0, 1, 2, 3, 4 ... The name of the class should be \n" +
                    "Counter. It has one private instance variable representing the value of the counter. It \n" +
                    "has two instance methods: increment() adds one to the counter value, and getValue() \n" +
                    "returns the current counter value. Write a complete definition for the class, Counter.");
                    System.out.println("*****ANSWER******");
                    System.out.println("Demonstrating the Counter class:");

                    // Create a counter
                    Counter counter = new Counter();
                    System.out.println("Counter sequence from 0 to 4:");

                    // Show initial value (0)
                    System.out.println("Current value: " + counter.getValue());

                    // Increment and show values up to 4
                    while (counter.getValue() < 4) {
                        counter.increment();
                        System.out.println("Current value: " + counter.getValue());
                    }
                    break;
                case 10:
                    System.out.println("QUESTION 10: This problem uses the Counter class from the previous question. The following \n" +
                    "program segment is meant to simulate tossing a coin 100 times. It should use two \n" +
                    "Counter objects, headCount and tailCount, to count the number of heads and the \n" +
                    "number of tails.");
                    System.out.println("*****ANSWER******");
                    // Create counters for heads and tails
                    Counter headCount = new Counter();
                    Counter tailCount = new Counter();

                    // Create random number generator
                    Random random = new Random();

                    // Simulate 100 coin tosses
                    for (int i = 0; i < 100; i++) {
                        // Generate random boolean (true for heads, false for tails)
                        boolean isHeads = random.nextBoolean();

                        if (isHeads) {
                            headCount.increment();
                        } else {
                            tailCount.increment();
                        }
                    }

                    // Print results
                    System.out.println("After 100 coin tosses:");
                    System.out.println("Heads: " + headCount.getValue());
                    System.out.println("Tails: " + tailCount.getValue());

                    // Verify total count
                    System.out.println("Total tosses: " + (headCount.getValue() + tailCount.getValue()));
                    break;
                case 11:
    System.out.println("PROBLEM 11: Suppose that a class, Employee, is defined as follows:\n" +
      "class Employee {\n" +
      " String lastName;\n" +
      " String firstName;\n" +
      " double hourlyWage;\n" +
      " int yearsWithCompany;\n" +
      "}\n" +
      "Suppose that data about 100 employees is already stored in an array:\n" +
      "Employee[] employeeData = new Employee[100];\n" +
      "Write a code segment that will output the first name, last name, and hourly wage of \n" +
      "each employee who has been with the company for 20 years or more");
    System.out.println("*****ANSWER******");
    
    // Clear the scanner buffer
    scanner.nextLine();
    
    System.out.print("Enter the number of employees (max 100): ");
    int employeeCount = scanner.nextInt();
    scanner.nextLine(); // consume newline
    
    // Validate input
    if (employeeCount <= 0 || employeeCount > 100) {
        System.out.println("Invalid number of employees. Please enter between 1 and 100.");
        break;
    }

    Employee[] employeeData = new Employee[employeeCount];

    // Input employee data
    System.out.println("\n=== ENTER EMPLOYEE DETAILS ===");
    for (int i = 0; i < employeeData.length; i++) {
        employeeData[i] = new Employee();
        System.out.println("\nEmployee #" + (i + 1));
        
        System.out.print("First Name: ");
        employeeData[i].firstName = scanner.nextLine();
        
        System.out.print("Last Name: ");
        employeeData[i].lastName = scanner.nextLine();
        
        System.out.print("Hourly Wage: ");
        employeeData[i].hourlyWage = scanner.nextDouble();
        scanner.nextLine(); // consume newline
        
        System.out.print("Years with Company: ");
        employeeData[i].yearsWithCompany = scanner.nextInt();
        scanner.nextLine(); // consume newline
    }

    // Display senior employees (20+ years)
    System.out.println("\n=== SENIOR EMPLOYEES (20+ YEARS) ===");
    boolean foundSenior = false;
    
    // Table header
    System.out.println("+------------+------------+--------------+---------------------+");
    System.out.printf("| %-10s | %-10s | %-12s | %19s |\n", "First Name", "Last Name", "Hourly Wage","years with camapany");
    System.out.println("+------------+------------+------------------------------------+");

    for (Employee emp : employeeData) {
        if (emp.yearsWithCompany >= 20) {
            System.out.printf("| %-10s | %-10s | %12.2f | %19s |\n", 
                emp.firstName, emp.lastName, emp.hourlyWage,emp.yearsWithCompany);
            foundSenior = true;
        }
    }

    if (!foundSenior) {
        System.out.println("| No employees with 20+ years found.       |");
    }
    System.out.println("+------------+------------+--------------+-------------------- +");
    break;
                case 12:
                    System.out.println("QUESTION 12: In all versions of the PairOfDice class, the instance variables die1 and die2 are \n" +
                     "declared to be public. They really should be private, so that they would be protected \n" +
                     "from being changed from outside the class. Write another version of the PairOfDice \n" +
                     "class in which the instance variables die1 and die2 are private. Your class will need \n" +
                     "\"getter\" methods that can be used to find out the values of die1 and die2. (The idea is \n" +
                     "to protect their values from being changed from outside the class, but still to allow the \n" +
                     "values to be read.) Include other improvements in the class, if you can think of any. \n" +
                     "Test your class with a short program that counts how many times a pair of dice is \n" +
                     "rolled, before the total of the two dice is equal to two.");
                    System.out.println("*****ANSWER******");
                    PairOfDice dice = new PairOfDice();
                    int rollCount = 0;

                    // Keep rolling until the total is 2
                    while (dice.getTotal() != 2) {
                        dice.roll();
                        rollCount++;
                        System.out.println("Roll " + rollCount + ": die1 = " + dice.getDie1() +
                                ", die2 = " + dice.getDie2() +
                                ", total = " + dice.getTotal());
                    }

                    System.out.println("It took " + rollCount + " rolls to get a total of 2.");
                    break;
                case 13:
                         System.out.println("QUESTION 13: The Fibonacci sequence of numbers is 1, 1, 2, 3, 5, 8, 13, 21, 34 ... The first and \n" +
                     "second numbers are 1 and after that ni = ni-2 + ni-1, e.g., 34 = 13 + 21. A number in the \n" +
                     "sequence is called a Fibonacci number. Write a method with signature int \n" +
                     "closestFibonacci(int n) which returns the largest Fibonacci number that is less than \n" +
                     "or equal to its argument. For example, closestFibonacci(12) returns 8 because 8 is the \n" +
                     "largest Fibonacci number less than 1112 and closestFibonacci(33) returns 21 because 21 \n" +
                     "is the largest Fibonacci number that is <= 33. ClosestFibonacci (34) should return 34. \n" +
                     "If the argument is less than 1 return 0. Your solution must not use recursion because \n" +
                     "unless you cache the Fibonacci numbers as you find them, the recursive solution \n" +
                     "recomputed the same Fibonacci number many times.");
                    System.out.println("*****ANSWER******");
                    // Test cases
                    System.out.println("closestFibonacci(12): " + closestFibonacci(12)); // Expected: 8
                    System.out.println("closestFibonacci(33): " + closestFibonacci(33)); // Expected: 21
                    System.out.println("closestFibonacci(34): " + closestFibonacci(34)); // Expected: 34
                    System.out.println("closestFibonacci(0): " + closestFibonacci(0));   // Expected: 0
                    System.out.println("closestFibonacci(1): " + closestFibonacci(1));   // Expected: 1
                    break;
                                case 14:
                    System.out.println("QUESTION 14: A number n is called prime-happy if there is at least one prime less than n and the \n" +
                    "sum of all primes less than n is evenly divisible by n.\n" +
                    "Recall that a prime number is an integer > 1 which has only two integer factors, 1 and \n" +
                    "itself\n" +
                    "Write a function named isPrimeHappy that returns 1 if its integer argument is prime-happy; otherwise it returns 0.");
                    System.out.println("*****ANSWER******");
                    System.out.println("\nPrime-Happy Number Checker");
                    System.out.println("Enter numbers to check (enter 0 to exit):");

                    while (true) {
                        System.out.print("Enter a number: ");
                        int n = scanner.nextInt();

                        if (n == 0) {
                            break;
                        }

                        int result = isPrimeHappy(n);
                        System.out.println("isPrimeHappy(" + n + ") returns " + result);
                    }
                    break;

                case 15:
                    System.out.println("QUESTION 15: Write a function that takes an array of integers as an argument and returns a \n" +
                     "value based on the sums of the even and odd numbers in the array. Let X = the \n" +
                     "sum of the odd numbers in the array and let Y = the sum of the even numbers. The \n" +
                     "function should return X - Y");
                    System.out.println("*****ANSWER******");
                    System.out.print("Enter array size: ");
                    int size = scanner.nextInt();
                    int[] arr = new int[size];
                    System.out.println("Enter " + size + " integers:");
                    for (int i = 0; i < size; i++) {
                        arr[i] = scanner.nextInt();
                    }
                    System.out.println("Result: " + sumOddsMinusEvens(arr));
                    break;

                case 16:
                    System.out.println("QUESTION 16: An array is defined to be stepped if it is in ascending order and there are 3 or more \n" +
                     "occurrences of each distinct value in the array. Note that ascending order \n" +
                     "means a[n]<=a[n+1]. It does not mean a[n] (this is strictly ascending). Write a \n" +
                     "function named isStepped that returns 1 if its array argument is stepped, otherwise \n" +
                     "return 0.");
                    System.out.println("*****ANSWER******");
                    System.out.print("Enter array size: ");
                    size = scanner.nextInt();
                    int[] steppedArr = new int[size];
                    System.out.println("Enter " + size + " integers:");
                    for (int i = 0; i < size; i++) {
                        steppedArr[i] = scanner.nextInt();
                    }
                    System.out.println("Is stepped: " + isStepped(steppedArr));
                    break;

                case 0:
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Invalid choice");
            }

            if (choice != 0) {
                System.out.print("\nContinue? (1=Yes, 0=No): ");
                choice = scanner.nextInt();
            }
        } while (choice != 0);

        scanner.close();
    }
}      